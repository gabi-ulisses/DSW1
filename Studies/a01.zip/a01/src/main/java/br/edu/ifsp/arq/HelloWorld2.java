package br.edu.ifsp.arq;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/hello")
public class HelloWorld2 extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String nome = req.getParameter("nome");
		int idade = Integer.parseInt(req.getParameter("idade"));

		PrintWriter out = resp.getWriter();

		out.append("<h1>Hello World De novo!</h1>");

		out.append("<h1>Nome: " + nome + "</h1>");
		out.append("<h1>Idade de Cachorro: " + (idade * 7) + "</h1>");
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String nomeTarefa = req.getParameter("nome");
		String descricao = req.getParameter("descricao");
		String periodos[] = req.getParameterValues("periodo");
		ArrayList<String> lista = new ArrayList<String>();
		
		for (String p : periodos) {
			lista.add(p);
		}
		
		Tarefa t = new Tarefa(nomeTarefa, descricao, lista);
		
		ArrayList<Tarefa> listaTarefas = (ArrayList<Tarefa>) getServletContext().getAttribute("lista");
		
		if(listaTarefas == null) {
			listaTarefas = new ArrayList<Tarefa>();
		}
		
		listaTarefas.add(t);
		
		
		getServletContext().setAttribute("lista", listaTarefas); // Conceito de dicionário

		PrintWriter out = resp.getWriter();
		
		String url = "/HiWorld";
		
		getServletContext().getRequestDispatcher(url).forward(req, resp);

		out.append("<h1>Tarefa: " + nomeTarefa + "</h1>");
		out.append("<h1>Descrição: " + descricao + "</h1>");
		
		
	}
}
