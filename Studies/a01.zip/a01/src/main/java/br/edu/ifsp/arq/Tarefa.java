package br.edu.ifsp.arq;

import java.util.ArrayList;

public class Tarefa {
	String nome;
	String descricao;
	ArrayList<String> atributos;
	

	public Tarefa(String n, String d, ArrayList<String> attr) {
		this.nome = n;
		this.descricao = d;
		this.atributos = attr;
	}


	public String getNome() {
		return nome;
	}


	public String getDescricao() {
		return descricao;
	}


	public ArrayList<String> getAtributos() {
		return atributos;
	}


	@Override
	public String toString() {
		String s = this.nome + "\n" + this.descricao + "\n";
		
		for (String a : atributos) {
			s += a + "\n";
		}
		
		return s;
	}

	
	
	
}
